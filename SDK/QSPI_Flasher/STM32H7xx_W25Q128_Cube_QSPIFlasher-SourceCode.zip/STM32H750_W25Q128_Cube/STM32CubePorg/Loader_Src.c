/* Includes ------------------------------------------------------------------*/
#include "sys.h"
#include "qspi.h"
#include "w25qxx.h"

#define QSPI_PAGESIZE 256
/*******************************************************************************
 Description :																			         
 Write data to the device	 														       
 Inputs :																					           
 				Address 	: Write location  										     
 				Size 		: Length in bytes 										     
 				buffer 		: Address where to get the data to write	 
 outputs :																				           
 				"1" 	        : Operation succeeded								       
 Info :																						           
 Note : Mandatory for all types except SRAM and PSRAM			   
********************************************************************************/
int Write (uint32_t Address, uint32_t Size, uint8_t* buffer)
{
	uint32_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;
  uint32_t   QSPI_DataNum = 0;
	
  Address = Address - QSPI_BASE;
	
  Addr = Address % QSPI_PAGESIZE;
  count = QSPI_PAGESIZE - Addr;
  NumOfPage =  Size / QSPI_PAGESIZE;
  NumOfSingle = Size % QSPI_PAGESIZE;

  if (Addr == 0) /*!< Address is QSPI_PAGESIZE aligned  */
  {
    if (NumOfPage == 0) /*!< NumByteToWrite < QSPI_PAGESIZE */
    {
      QSPI_DataNum = Size;      
      W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
    }
    else /*!< Size > QSPI_PAGESIZE */
    {
      while (NumOfPage--)
      {
        QSPI_DataNum = QSPI_PAGESIZE;
        W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
        Address +=  QSPI_PAGESIZE;
        buffer += QSPI_PAGESIZE;
      }
      
      QSPI_DataNum = NumOfSingle;
      W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
    }
  }
  else /*!< Address is not QSPI_PAGESIZE aligned  */
  {
    if (NumOfPage == 0) /*!< Size < QSPI_PAGESIZE */
    {
      if (NumOfSingle > count) /*!< (Size + Address) > QSPI_PAGESIZE */
      {
        temp = NumOfSingle - count;
        QSPI_DataNum = count;
        W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
        Address +=  count;
        buffer += count;
        
        QSPI_DataNum = temp;
        W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
      }
      else
      {
        QSPI_DataNum = Size; 
        W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
      }
    }
    else /*!< Size > QSPI_PAGESIZE */
    {
      Size -= count;
      NumOfPage =  Size / QSPI_PAGESIZE;
      NumOfSingle = Size % QSPI_PAGESIZE;

      QSPI_DataNum = count;
        
      W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
      Address +=  count;
      buffer += count;

      while (NumOfPage--)
      {
        QSPI_DataNum = QSPI_PAGESIZE;
        
        W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
        Address +=  QSPI_PAGESIZE;
        buffer += QSPI_PAGESIZE;
      }

      if (NumOfSingle != 0)
      {
        QSPI_DataNum = NumOfSingle;
        
        W25QXX_Write_Page(buffer,Address, QSPI_DataNum);
      }
    }
  }
	
	return 1;
}

/*******************************************************************************
 Description :																			
 Erase a full sector in the device 									
 Inputs :																					  
 				SectrorAddress	: Start of sector 					
 outputs :																				  
 				"1" : Operation succeeded										
 				"0" : Operation failure											
 Note : Not Mandatory for SRAM PSRAM and NOR_FLASH		
********************************************************************************/
int SectorErase (uint32_t EraseStartAddress ,uint32_t EraseEndAddress)
{
	uint32_t BlockAddr;
	
	EraseStartAddress = EraseStartAddress - QSPI_BASE;
	EraseEndAddress = EraseEndAddress - QSPI_BASE;
	
	EraseStartAddress = EraseStartAddress -  EraseStartAddress % 0x10000;
	
	while (EraseEndAddress>=EraseStartAddress)
	{
		BlockAddr = EraseStartAddress & 0x0FFFFFFF;
		W25QXX_Erase_Block( BlockAddr);
    EraseStartAddress += 0x10000;
	}
 	return 1;	
}

/*******************************************************************************
 Description :																			
 Read data from the device	 														
 Inputs :																					
 				Address 	: Write location  										
 				Size 		: Length in bytes 										
 				buffer 		: Address where to get the data to write		
 outputs :																				
 				"1" 		: Operation succeeded								
 				"0" 		: Operation failure										
 Note : Not Mandatory                               
********************************************************************************/	
int Read (uint32_t Address, uint32_t Size, uint8_t* Buffer)
{    
	uint32_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;
  uint32_t   QSPI_DataNum = 0;
	
  Address = Address - QSPI_BASE;
	
  Addr = Address % QSPI_PAGESIZE;
  count = QSPI_PAGESIZE - Addr;
  NumOfPage =  Size / QSPI_PAGESIZE;
  NumOfSingle = Size % QSPI_PAGESIZE;

  if (Addr == 0) /*!< Address is QSPI_PAGESIZE aligned  */
  {
    if (NumOfPage == 0) /*!< NumByteToWrite < QSPI_PAGESIZE */
    {
      QSPI_DataNum = Size;      
      W25QXX_Read(Buffer,Address, QSPI_DataNum);
    }
    else /*!< Size > QSPI_PAGESIZE */
    {
      while (NumOfPage--)
      {
        QSPI_DataNum = QSPI_PAGESIZE;
        W25QXX_Read(Buffer,Address, QSPI_DataNum);
        Address +=  QSPI_PAGESIZE;
        Buffer += QSPI_PAGESIZE;
      }
      
      QSPI_DataNum = NumOfSingle;
      W25QXX_Read(Buffer,Address, QSPI_DataNum);
    }
  }
  else /*!< Address is not QSPI_PAGESIZE aligned  */
  {
    if (NumOfPage == 0) /*!< Size < QSPI_PAGESIZE */
    {
      if (NumOfSingle > count) /*!< (Size + Address) > QSPI_PAGESIZE */
      {
        temp = NumOfSingle - count;
        QSPI_DataNum = count;
        W25QXX_Read(Buffer,Address, QSPI_DataNum);
        Address +=  count;
        Buffer += count;
        
        QSPI_DataNum = temp;
        W25QXX_Read(Buffer,Address, QSPI_DataNum);
      }
      else
      {
        QSPI_DataNum = Size; 
        W25QXX_Read(Buffer,Address, QSPI_DataNum);
      }
    }
    else /*!< Size > QSPI_PAGESIZE */
    {
      Size -= count;
      NumOfPage =  Size / QSPI_PAGESIZE;
      NumOfSingle = Size % QSPI_PAGESIZE;

      QSPI_DataNum = count;
        
      W25QXX_Read(Buffer,Address, QSPI_DataNum);
      Address +=  count;
      Buffer += count;

      while (NumOfPage--)
      {
        QSPI_DataNum = QSPI_PAGESIZE;
        
        W25QXX_Read(Buffer,Address, QSPI_DataNum);
        Address +=  QSPI_PAGESIZE;
        Buffer += QSPI_PAGESIZE;
      }

      if (NumOfSingle != 0)
      {
        QSPI_DataNum = NumOfSingle;
        
        W25QXX_Read(Buffer,Address, QSPI_DataNum);
      }
    }
  }
	
	return 1;     
} 

/*******************************************************************************
 Description :																		
 Verify the data 	 														    
 Inputs :																					
 				MemoryAddr 	: Write location  					
 				RAMBufferAddr 	: RAM Address		          
 				Size 		: Length in bytes 								
 outputs :																				
 				"0" 		: Operation succeeded						
 Note : Not Mandatory                             	
********************************************************************************/
int Verify (uint32_t MemoryAddr, uint32_t RAMBufferAddr, uint32_t Size)
{ 
	uint8_t Buffer[4096*16];
	uint32_t p;
	uint32_t VerifiedData = 0;
	Size*=4;
	
  MemoryAddr = MemoryAddr - QSPI_BASE;
	
  p = 0;
  W25QXX_Read(Buffer,MemoryAddr,Size);
	
  while (Size>VerifiedData)
  {
		if ( Buffer[p++] != *((uint8_t*)RAMBufferAddr + VerifiedData))
			return (p + QSPI_BASE + VerifiedData);  
		
		VerifiedData++;  
  }
        
  return 0;
}
/*******************************************************************************
 Description :																		
 System initialization										        
 Inputs 	:																        
 				 None 																		
 outputs 	:																				
 				"1" 		: Operation succeeded						
 				"0" 		: Operation failure							
********************************************************************************/
int Init (void)
{ 
  Stm32_Clock_Init(50, 1, 2, 2); //����ʱ��400MHz��ʹ��HSI 64MHz RC
	W25QXX_Init(); //W25QXX��ʼ��
	//W25QXX_Write_Enable(); //SET WEL
  return 1;
}


