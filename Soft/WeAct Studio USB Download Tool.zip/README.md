# WeAct Studio USB Download Tool
实现USB一键下载固件
1. 按住BOOT0键，然后连接电脑
2. 设备管理器会出现DFU设备
3. 如果没有驱动，可以进入DFU_Driver文件夹，双击`STM32Bootloader.bat`进行安装
4. 双击`WeAct Studio USB Download Tool.bat`,输入目标固件名，回车即可开始下载

> English Description

1. Hold down the BOOT0 key and connect to the computer

2. DFU devices will appear in the device manager

3. If there is no driver, you can enter the DFU_Driver folder and double-click `STM32Bootloader.Bat` to install

4. Double-click `WeAct Studio USB Download Tool. Bat`, enter the target firmware name and press enter to start downloading